Plugin files go in this directory
TunerStudio will check this directory for plugin application extensions
Read more on:
http://www.efianalytics.com/TunerStudio/plugins.html
